export const book = {
  login: '/login',
  signup: '/registration11111',
  profile: '/profile',
  mail: '/mail',
};
